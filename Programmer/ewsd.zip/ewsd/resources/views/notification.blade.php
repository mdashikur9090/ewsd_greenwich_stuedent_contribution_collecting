@extends('app')

@section('content')
    
        <!--main content start-->
        <section id="main-content">
            
            <section class="container-fluid">
                <div class="row" style="margin-top: 100px;">

                	<div class="col-md-12">
                		<a href="#">
                            <span class="photo"><img alt="avatar" src="{{ asset('images/3.png') }}"></span>
                            <span class="subject">
                                <span class="from">Jonathan Smith</span>
                                <span class="time">Just now</span>
                            </span>
                            <span class="message">
                                Hello, this is an example msg.
                            </span>
                        </a>
                	</div>

                	



                </div>



                        



                	

                	<!-- footer -->
            <div class="footer" style="margin-top: 800px;">
                <div class="wthree-copyright">
                    <p>© 2019 Visitors. All rights reserved</p>
                </div>
            </div>
            <!-- / footer -->
        </section>
        <!--main content end-->
    
@endsection

@section('modal-or-js')



    <script>

            
    </script>
        

@endsection