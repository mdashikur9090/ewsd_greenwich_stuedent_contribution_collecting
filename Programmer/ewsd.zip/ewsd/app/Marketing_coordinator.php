<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Marketing_coordinator extends Model
{
    //
}
