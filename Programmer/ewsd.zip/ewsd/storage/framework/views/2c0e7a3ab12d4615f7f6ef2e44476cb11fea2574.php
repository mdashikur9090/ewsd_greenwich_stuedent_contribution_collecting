<?php $__env->startSection('content'); ?>
    
        <!--main content start-->
        <section id="main-content">
            
            <section class="container-fluid">

                <div class="" style="margin-top: 90px;">
                    <div class="panel-heading" style="margin-bottom: 20px;">
                            Contributions without a comment. (Total=<?php echo e(count($conWithoutcommnets)); ?>)
                    </div>
                    <!--Submited contribution Table-->
                        <table class="table">
                            <thead>
                              <tr>
                                <th>NO</th>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>Faculty Name</th>
                                <th>Submission Date</th>
                                <th>Doc or Imagee</th>
                                <th>Comments</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php ($no=0); ?>
                                <?php $__currentLoopData = $conWithoutcommnets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contribution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no+=1); ?> </td>
                                        <td><?php echo e($contribution->student_id); ?></td>
                                        <td><?php echo e($contribution->studentInfo->first_name." ".$contribution->studentInfo->last_name); ?></td>
                                        <td><?php echo e($contribution->studentInfo->facultyInfo->name); ?></td>
                                        <td><?php echo e($contribution->created_at); ?></td>
                                        <td class="downloads">
                                            <a href="<?php echo e(URL('contributions').'/'.$contribution->doc_or_image); ?>" download>
                                                <?php if(substr( $contribution->doc_or_image, -5) ==".docx"): ?>
                                                    <img src="<?php echo e(asset('images/docx.png')); ?>" width="100px" height="100px"  alt="">
                                                <?php else: ?>
                                                    <img src="<?php echo e(URL('contributions').'/'.$contribution->doc_or_image); ?>" width="100px" height="100px"  alt="">
                                                <?php endif; ?>
                                            </a>
                                        </td>
                                        <td><?php echo e($contribution->comment); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>








                    <div class="panel-heading" style="margin-bottom: 20px;">
                        Contributions without a comment after 14 days. (Total=<?php echo e(count($expiedCommnets)); ?>)
                    </div>
                    <!--Submited contribution Table-->
                    <table class="table">
                        <thead>
                          <tr>
                            <th>NO</th>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Faculty Name</th>
                            <th>Submission Date</th>
                            <th>Doc or Imagee</th>
                            <th>Comments</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php ($no=0); ?>
                            <?php $__currentLoopData = $expiedCommnets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expiredComment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+=1); ?> </td>
                                    <td><?php echo e($expiredComment->student_id); ?></td>
                                    <td><?php echo e($expiredComment->studentInfo->first_name." ".$expiredComment->studentInfo->last_name); ?></td>
                                    <td><?php echo e($expiredComment->studentInfo->facultyInfo->name); ?></td>
                                    <td><?php echo e($expiredComment->created_at); ?></td>
                                    <td class="downloads">
                                        <a href="<?php echo e(URL('contributions').'/'.$expiredComment->doc_or_image); ?>" download>
                                            <?php if(substr( $expiredComment->doc_or_image, -5) ==".docx"): ?>
                                                <img src="<?php echo e(asset('images/docx.png')); ?>" width="100px" height="100px"  alt="">
                                            <?php else: ?>
                                                <img src="<?php echo e(URL('contributions').'/'.$expiredComment->doc_or_image); ?>" width="100px" height="100px"  alt="">
                                            <?php endif; ?>
                                        </a>
                                    </td>
                                    <td><?php echo e($expiredComment->comment); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                     

                </div>
            </section>
			
			
			
			
            



            <!-- footer -->
            <div class="footer">
                <div class="wthree-copyright">
                    <p>© 2019 Visitors. All rights reserved</p>
                </div>
            </div>
            <!-- / footer -->
        </section>
        <!--main content end-->
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>