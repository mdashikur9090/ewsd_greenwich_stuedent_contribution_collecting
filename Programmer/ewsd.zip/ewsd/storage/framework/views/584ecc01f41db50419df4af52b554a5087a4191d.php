<?php $__env->startSection('content'); ?>


<!-- container start -->
    <div class="container-bg">
        <div class="login-box-new">
            <!-- form-group start -->
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

              <div class="form-group">
                <h2>Login</h2>
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <input class="control-form<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" type="email" name="email" value="" placeholder="Email" value="<?php echo e(old('email')); ?>" required autofocus>
              </div>
              <div class="form-group">
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
              <div class="form-group group-wor">
                <i  class="fas fa-key" class="fa fa-envelope" aria-hidden="true"></i>
                <input class="control-form" type="password" name="password" value="" placeholder="Password">
              </div>
              <div class="form-group">
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

                <button class="btn-color-f"><i class="fa fa-paper-plane send-fa" aria-hidden="true"></i>Login</button>
                <!-- button start -->
                <a href="#">  <button type="button" class="btn-bg-n">sign up </button></a>
                <!-- button finish -->

            </form>
            <!-- form-group finish-->
          </div>
    </div>
    <!-- container finish -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>