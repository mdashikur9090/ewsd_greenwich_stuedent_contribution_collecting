<!DOCTYPE html>
<head>
<title>Login</title>

<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="<?php echo e(asset('css/style.css')); ?>" rel='stylesheet' type='text/css' />
<link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet"/>
<!-- font CSS -->
<!--     Fonts and icons     -->
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
<!-- font-awesome icons -->
<link rel="stylesheet" href="<?php echo e(asset('css/font.css')); ?>" type="text/css"/>
<link href="<?php echo e(asset('css/font-awesome.css')); ?>" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="<?php echo e(asset('js/jquery2.0.3.min.js')); ?>"></script>

<!-- charts -->
<script src="<?php echo e(asset('js/raphael-min.js')); ?>"></script>
<script src="<?php echo e(asset('js/morris.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/morris.css')); ?>">
<!-- //charts -->


</head>
<body>

	<section id="container">
        <!--header start-->
        <header class="header fixed-top clearfix">
            <!--logo start-->
            <div class="brand">

                <a href="<?php echo e(URL('/')); ?>" class="logo">
                    GreenWich
                </a>
                <div class="sidebar-toggle-box">
                    <div class="fa fa-bars"></div>
                </div>
            </div>
            <!--logo end-->

            <?php if(Auth::user()->role==3): ?>
                <div class="nav notify-row" id="top_menu">
                    <!--  notification start -->
                    <ul class="nav top-menu">
                        <!-- inbox dropdown start-->
                        <li id="header_inbox_bar" class="dropdown">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <i class="fa fa-envelope-o"></i>
                                <span class="badge bg-important"><?php echo e(count($notifications)); ?></span>
                            </a>
                            <ul class="dropdown-menu extended inbox">
                                <li>
                                    <p class="red">You have <?php echo e(count($notifications)); ?> Mails</p>
                                </li>
                                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <li>
                                        <a href="<?php echo e(URL('/notification').'/'.$notification->id); ?>">
                                            <span class="photo"><img alt="avatar" src="<?php echo e(asset('images/3.png')); ?>"></span>
                                            <span class="subject">
                                                <span class="from"><?php echo e($notification->first_name." ".$notification->last_name); ?></span>
                                                <span class="time"><?php echo e($notification->created_at); ?></span>
                                            </span>
                                            <span class="message">
                                                Submited a new Contribution.
                                            </span>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <!-- inbox dropdown end -->
                    </ul>
                    <!--  notification end -->
                </div>
            <?php elseif(Auth::user()->role==4): ?>
                <div class="nav notify-row" id="top_menu">
                    <!--  notification start -->
                    <ul class="nav top-menu">
                        <!-- inbox dropdown start-->
                        <li id="header_inbox_bar" class="dropdown">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <i class="fa fa-envelope-o"></i>
                                <span class="badge bg-important"><?php echo e(count($messages)); ?></span>
                            </a>
                            <ul class="dropdown-menu extended inbox">
                                <li>
                                    <p class="red">You have <?php echo e(count($messages)); ?> Message</p>
                                </li>
                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <li>
                                        <a href="<?php echo e(URL('/message/seen').'/'.$message->id); ?>">
                                            <span class="photo"><img alt="avatar" src="<?php echo e(asset('images/3.png')); ?>"></span>
                                            <span class="subject">
                                                <span class="from"><?php echo e($message->name); ?></span>
                                                <span class="time"><?php echo e($message->created_at); ?></span>
                                            </span>
                                            <span class="message">
                                                Your have new message form <?php echo e($message->name); ?>

                                            </span>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <!-- inbox dropdown end -->
                    </ul>
                    <!--  notification end -->
                </div>
            <?php endif; ?>


            <div class="top-nav clearfix">
                <!--search & user info start-->
                <ul class="nav pull-right top-menu">
                    <!-- user login dropdown start-->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <img alt="" src="<?php echo e(asset('images/avater.png')); ?>">
							<?php if(Auth::user()->role==4): ?>
								<span class="username"><?php echo e($userInformation[0]->first_name); ?></span>
							<?php else: ?>
								<span class="username"><?php echo e($userInformation[0]->name); ?></span>
							<?php endif; ?>
                            
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <li><a href="#"><i class=" fa fa-suitcase"></i>Profile</a></li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->

                </ul>
                <!--search & user info end-->
            </div>
        </header>
        <!--header end-->
        <!--sidebar start-->
        <aside>
            <div id="sidebar" class="nav-collapse">
                <!-- sidebar menu start-->
                <div class="leftside-navigation">
                    <ul class="sidebar-menu" id="nav-accordion">
                        <li>
                            <a class="<?php echo e(Request::is('/') ? 'active' : ''); ?>" href="<?php echo e(URL('/')); ?>">
                                <i class="fa fa-dashboard"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a class="<?php echo e(Request::is('magazine') ? 'active' : ''); ?>"  href="<?php echo e(URL('/magazine')); ?>">
                                <i class="fa fa-dashboard"></i>
                                <span>Magazine</span>
                            </a>
						</li>
						<?php if(Auth::user()->role == 1): ?>
							<li>
								<a class="<?php echo e(Request::is('magazine/create') ? 'active' : ''); ?>" href="<?php echo e(URL('/magazine/create')); ?>">
									<i class="fa fa-dashboard"></i>
									<span>Create Magazine</span>
								</a>
							</li>
                            <li>
                                <a class="<?php echo e(Request::is('report/statistics') ? 'active' : ''); ?>" href="<?php echo e(URL('/report/statistics')); ?>">
                                    <i class="fa fa-dashboard"></i>
                                    <span>Statistics Reports</span>
                                </a>
                            </li>
                            <li>
                                <a class="<?php echo e(Request::is('report/exception') ? 'active' : ''); ?>" href="<?php echo e(URL('/report/exception')); ?>">
                                    <i class="fa fa-dashboard"></i>
                                    <span>Exception reports</span>
                                </a>
                            </li>
						<?php elseif(Auth::user()->role == 2): ?>
						<?php elseif(Auth::user()->role == 3): ?>
						<?php elseif(Auth::user()->role == 4): ?>
							<li>
                                <a class="<?php echo e(Request::is('message') ? 'active' : ''); ?>"  href="<?php echo e(URL('/message')); ?>">
                                    <i class="fa fa-dashboard"></i>
                                    <span>Message</span>
                                </a>
                            </li>
						<?php endif; ?>
                    </ul>
                </div>
                <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->

	
    	<?php echo $__env->yieldContent('content'); ?>


    </section>


    <?php echo $__env->yieldContent('modal-or-js'); ?>
    
    
	<script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.dcjqaccordion.2.7.js')); ?>"></script>
	<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.slimscroll.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.nicescroll.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.scrollTo.js')); ?>"></script>
</body>
</html>