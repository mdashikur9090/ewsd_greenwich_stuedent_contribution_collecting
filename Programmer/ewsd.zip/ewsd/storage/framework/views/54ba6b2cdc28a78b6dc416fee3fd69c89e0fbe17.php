<?php $__env->startSection('content'); ?>
    
    <!--main content start-->
    <section id="main-content">
        
        <section class="container-fluid">
            <div class="row text-center" style="margin-top: 100px;">
            	<div class="panel-heading" style="margin-bottom: 30px;">
                    Messages
                </div>

				<?php if( Auth::user()->role==4): ?>
                        <?php $__currentLoopData = $allMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        	<div class="row">
                        		<div class="col-md-2">
                        			
                        			<span class="photo"><img alt="avatar" src="<?php echo e(asset('images/avater.png')); ?>"></span>
                        		</div>
                        		<div class="col-md-2">
                        			<h5><span class="from"><?php echo e($message->name); ?></span></h5>
                        		</div>
                        		<div class="col-md-6">
                        			<?php echo e($message->message); ?>

                        		</div>
                        		<div class="col-md-2">
                        			<?php echo e($message->created_at); ?>

                        		</div>
                        	</div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>

            </div>
        </section>
		

        <!-- footer -->
        <div class="footer" style="margin-top: 700px; >
            <div class="wthree-copyright">
                <p>© 2019 Visitors. All rights reserved</p>
            </div>
        </div>
        <!-- / footer -->
    </section>
    <!--main content end-->
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>