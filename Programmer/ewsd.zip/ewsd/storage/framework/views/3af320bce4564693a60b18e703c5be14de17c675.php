<?php $__env->startSection('content'); ?>
    
    <!--main content start-->
    <section id="main-content">
        
        <section class="container-fluid">
            <div class="row text-center" style="margin-top: 100px;">
                <div class="panel-heading">
                	Magazine
				</div>

				<?php if( Auth::user()->role==1 || Auth::user()->role==2): ?>

					<table class="table text-center" >
						<thead>
							<tr>
								<th class="text-center">Name</th>
								<th class="text-center">Start Data</th>
								<th class="text-center">Close Date</th>
								<th class="text-center">Final Close Date</th>
								<th class="text-center">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $magazines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $magazine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($magazine->name); ?></td>
									<td><?php echo e($magazine->start_date); ?></td>
									<td><?php echo e($magazine->end_date); ?></td>
									<td><?php echo e($magazine->final_end_date); ?></td>
									<td> 
										<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editmodal_<?php echo e($magazine->id); ?>">
                                            <i class="material-icons btn-primary">edit</i>
                                        </button>
                                        <button type="button" class="btn btn-primary">
                                           <a href="<?php echo e(url('magazine/'.$magazine->id)); ?>">
												<i class="material-icons btn-primary">arrow_right_alt</i>
											</a>
                                        </button>
										
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</tbody>
					</table>

						<?php $__currentLoopData = $magazines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $magazine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<!--START modal-->
                            <div class="modal fade" id="editmodal_<?php echo e($magazine->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <form action="<?php echo e(route('magazine.update', $magazine->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <div class="modal-body">
                                            <div class="form-group row">
						    					<label for="name" class="col-md-4 col-form-label text-md-right">Magazine Name</label>

						    					<div class="col-md-6">
						    						<input id="name" type="text" class="form-control" name="name" value="<?php echo e($magazine->name); ?>" required >
						    					</div>
						    				</div>
						    				
						    				<div class="form-group row">
						    					<label for="start_date" class="col-md-4 col-form-label text-md-right">Start Date</label>

						    					<div class="col-md-6">
						    						<input id="start_date" type="date" class="form-control" name="start_date" value="<?php echo e($magazine->start_date); ?>" required >
						    					</div>
						    				</div>
						    				
						    				<div class="form-group row">
						    					<label for="end_date" class="col-md-4 col-form-label text-md-right">End Date</label>

						    					<div class="col-md-6">
						    						<input id="end_date" type="date" class="form-control" name="end_date" value="<?php echo e($magazine->end_date); ?>" required >
						    					</div>
						    				</div>
						    				
						    				<div class="form-group row">
						    					<label for="final_close_date" class="col-md-4 col-form-label text-md-right">Final Close Date</label>

						    					<div class="col-md-6">
						    						<input id="final_close_date" type="date" class="form-control" name="final_close_date" value="<?php echo e($magazine->final_end_date); ?>" required >
						    					</div>
    										</div>          
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Save changes</button>
                                        </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                            <!--End modal-->

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php else: ?>

					<table class="table text-center" >
						<thead>
							<tr>
								<th class="text-center">Name</th>
								<th class="text-center">Start Data</th>
								<th class="text-center">Close Date</th>
								<th class="text-center">Final Close Date</th>
								<th class="text-center">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $magazines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $magazine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($magazine->name); ?></td>
									<td><?php echo e($magazine->start_date); ?></td>
									<td><?php echo e($magazine->end_date); ?></td>
									<td><?php echo e($magazine->final_end_date); ?></td>
									<td> 
										<button type="button" class="btn btn-primary">
											<a href="<?php echo e(url('magazine/'.$magazine->id)); ?>">
												<i class="material-icons btn-primary">arrow_right_alt</i>
											</a>
										</button>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</tbody>
					</table>
				<?php endif; ?>

				


            </div>
        </section>
		

        <!-- footer -->
        <div class="footer" style="margin-top: 600px; >
            <div class="wthree-copyright">
                <p>© 2019 Visitors. All rights reserved</p>
            </div>
        </div>
        <!-- / footer -->
    </section>
    <!--main content end-->
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>