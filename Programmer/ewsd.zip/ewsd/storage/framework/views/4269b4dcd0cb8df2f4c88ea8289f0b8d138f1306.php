<?php $__env->startSection('content'); ?>

    <!--main content start-->
    <section id="main-content">
        
        <section class="container-fluid">
            <div class="alert alert-success text-center" style="margin-top: 100px;">
                
                <?php if(Auth::user()->role == 1): ?>
                    You Are login as Adminstrator.
                <?php elseif(Auth::user()->role == 2): ?>
                    You Are login as Marketing Manager.
                <?php elseif(Auth::user()->role == 3): ?>
                    You Are login as Marketing Coordinator.
                <?php elseif(Auth::user()->role == 4): ?>
                    You Are login as student.
                <?php endif; ?>



            </div>
        </section>
        
        



        <!-- footer -->
        <div class="footer" style="margin-top: 700px; >
            <div class="wthree-copyright">
                <p>© 2019 Visitors. All rights reserved</p>
            </div>
        </div>
        <!-- / footer -->
    </section>
    <!--main content end-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>